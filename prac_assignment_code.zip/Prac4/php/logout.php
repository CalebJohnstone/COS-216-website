<!DOCTYPE html>
<html>
  <head>
  <script src="../javascript/logout.js"></script>
  <meta http-equiv='refresh' content='0; url=launchPage.php'> 
  </head>

  <body></body>

</hmtl>