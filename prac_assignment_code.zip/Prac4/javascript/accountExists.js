$(document).ready(function(){
    alert("That email has already been used to make an account with us");    
    window.location.assign("../php/signup.php");
});