$(".footer").css({
    "visibility" : "hidden",
    "bottom" : "-200px"
}
);