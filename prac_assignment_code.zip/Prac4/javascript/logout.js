localStorage.removeItem("API_key");
localStorage.removeItem("seen_message");