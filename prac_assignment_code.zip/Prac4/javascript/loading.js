$(document).ready(function (){
    $("#loadScreen").delay(2000).fadeOut();
});