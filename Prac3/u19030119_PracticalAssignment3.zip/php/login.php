<!DOCTYPE html>
  <head>
    <title>Log In</title>
    <link rel="stylesheet" href="../css/styles.css" type="text/css">
    <script src="../javascript/jquery-3.4.1.min.js"></script>
    <link rel="icon" sizes="180x180" href="../images/logo.png">
    
    <style>
      body{
        background-image: url("../images/background.jpg");
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
      }
    </style>
  
  </head>

  <body> 
    <?php 
      require_once("header.php");
      require_once("footer.php");
    ?>  

    <div class="songSection">
        <div class="song">
            <p>Log In page under construction</p>
        </div>
    </div>

   </body>
</html>