$(document).ready(function (){
    $("#loadScreen").delay(1000).fadeOut();
});